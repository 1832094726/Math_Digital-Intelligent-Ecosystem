// K-12数学教育系统数据库结构数据
const databaseSchema = {
    // 数据表定义
    tables: {
        // 用户权限系统
        users: {
            name: 'users',
            displayName: '用户基础信息',
            category: 'user',
            description: '存储所有用户的基础信息，包括学生、教师、管理员、家长等',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '用户ID' },
                { name: 'username', type: 'varchar(50)', isUnique: true, description: '用户名' },
                { name: 'email', type: 'varchar(100)', isUnique: true, description: '邮箱' },
                { name: 'password_hash', type: 'varchar(255)', description: '密码哈希' },
                { name: 'role', type: 'enum', values: ['student','teacher','admin','parent','tutor'], description: '用户角色' },
                { name: 'real_name', type: 'varchar(50)', description: '真实姓名' },
                { name: 'gender', type: 'enum', values: ['male','female','other'], description: '性别' },
                { name: 'birth_date', type: 'date', description: '出生日期' },
                { name: 'phone', type: 'varchar(20)', description: '手机号' },
                { name: 'avatar', type: 'varchar(255)', description: '头像URL' },
                { name: 'school_id', type: 'bigint(20)', isForeignKey: true, references: 'schools.id', description: '所属学校ID' },
                { name: 'grade_id', type: 'bigint(20)', isForeignKey: true, references: 'grades.id', description: '年级ID(学生)' },
                { name: 'class_id', type: 'bigint(20)', isForeignKey: true, references: 'classes.id', description: '班级ID(学生)' },
                { name: 'student_number', type: 'varchar(50)', description: '学号' },
                { name: 'teacher_number', type: 'varchar(50)', description: '教师编号' },
                { name: 'profile', type: 'json', description: '用户配置信息' },
                { name: 'learning_preferences', type: 'json', description: '学习偏好设置' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否激活' },
                { name: 'last_login_time', type: 'datetime', description: '最后登录时间' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'schools', foreignKey: 'school_id', description: '用户属于学校' },
                { type: 'belongsTo', table: 'grades', foreignKey: 'grade_id', description: '学生属于年级' },
                { type: 'belongsTo', table: 'classes', foreignKey: 'class_id', description: '学生属于班级' },
                { type: 'hasMany', table: 'user_sessions', localKey: 'id', description: '用户有多个会话' },
                { type: 'hasMany', table: 'notifications', localKey: 'id', description: '用户有多个通知' },
                { type: 'hasMany', table: 'homework_submissions', localKey: 'id', description: '用户有多个作业提交' },
                { type: 'hasMany', table: 'homework_progress', localKey: 'id', description: '用户有多个答题进度' }
            ]
        },

        user_sessions: {
            name: 'user_sessions',
            displayName: '用户会话',
            category: 'user',
            description: '管理用户登录会话和令牌',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '会话ID' },
                { name: 'user_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '用户ID' },
                { name: 'session_token', type: 'varchar(255)', isUnique: true, description: '会话令牌' },
                { name: 'refresh_token', type: 'varchar(255)', description: '刷新令牌' },
                { name: 'device_type', type: 'varchar(50)', description: '设备类型' },
                { name: 'device_id', type: 'varchar(100)', description: '设备ID' },
                { name: 'ip_address', type: 'varchar(45)', description: 'IP地址' },
                { name: 'user_agent', type: 'text', description: '用户代理' },
                { name: 'expires_at', type: 'datetime', description: '过期时间' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否活跃' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'user_id', description: '会话属于用户' }
            ]
        },

        notifications: {
            name: 'notifications',
            displayName: '通知消息',
            category: 'user',
            description: '系统通知和消息管理',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '通知ID' },
                { name: 'user_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '用户ID' },
                { name: 'title', type: 'varchar(200)', description: '通知标题' },
                { name: 'content', type: 'text', description: '通知内容' },
                { name: 'type', type: 'enum', values: ['system','homework','grade','reminder'], description: '通知类型' },
                { name: 'priority', type: 'enum', values: ['low','normal','high','urgent'], description: '优先级' },
                { name: 'is_read', type: 'tinyint(1)', defaultValue: '0', description: '是否已读' },
                { name: 'read_at', type: 'datetime', description: '阅读时间' },
                { name: 'expires_at', type: 'datetime', description: '过期时间' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'user_id', description: '通知属于用户' }
            ]
        },

        // 学校组织架构
        schools: {
            name: 'schools',
            displayName: '学校基础信息',
            category: 'school',
            description: '学校基本信息和配置',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '学校ID' },
                { name: 'school_name', type: 'varchar(200)', description: '学校名称' },
                { name: 'school_code', type: 'varchar(50)', isUnique: true, description: '学校代码' },
                { name: 'school_type', type: 'enum', values: ['primary','middle','high','mixed'], description: '学校类型' },
                { name: 'education_level', type: 'varchar(50)', description: '教育层次' },
                { name: 'curriculum_system', type: 'varchar(100)', description: '课程体系' },
                { name: 'address', type: 'varchar(500)', description: '学校地址' },
                { name: 'contact_info', type: 'json', description: '联系信息' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否启用' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'hasMany', table: 'grades', localKey: 'id', description: '学校有多个年级' },
                { type: 'hasMany', table: 'users', localKey: 'id', description: '学校有多个用户' },
                { type: 'hasMany', table: 'curriculum_standards', localKey: 'id', description: '学校有多个课程标准' }
            ]
        },

        grades: {
            name: 'grades',
            displayName: '年级信息',
            category: 'school',
            description: '年级基本信息和配置',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '年级ID' },
                { name: 'school_id', type: 'bigint(20)', isForeignKey: true, references: 'schools.id', description: '学校ID' },
                { name: 'grade_name', type: 'varchar(50)', description: '年级名称' },
                { name: 'grade_level', type: 'int(11)', description: '年级等级(1-12)' },
                { name: 'academic_year', type: 'varchar(20)', description: '学年' },
                { name: 'grade_config', type: 'json', description: '年级配置' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否启用' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'schools', foreignKey: 'school_id', description: '年级属于学校' },
                { type: 'hasMany', table: 'classes', localKey: 'id', description: '年级有多个班级' },
                { type: 'hasMany', table: 'users', localKey: 'id', description: '年级有多个学生' }
            ]
        },

        classes: {
            name: 'classes',
            displayName: '班级信息',
            category: 'school',
            description: '班级基本信息和管理',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '班级ID' },
                { name: 'grade_id', type: 'bigint(20)', isForeignKey: true, references: 'grades.id', description: '年级ID' },
                { name: 'class_name', type: 'varchar(50)', description: '班级名称' },
                { name: 'class_code', type: 'varchar(50)', description: '班级代码' },
                { name: 'head_teacher_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '班主任ID' },
                { name: 'max_students', type: 'int(11)', defaultValue: '50', description: '最大学生数' },
                { name: 'current_students', type: 'int(11)', defaultValue: '0', description: '当前学生数' },
                { name: 'class_config', type: 'json', description: '班级配置' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否启用' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'grades', foreignKey: 'grade_id', description: '班级属于年级' },
                { type: 'belongsTo', table: 'users', foreignKey: 'head_teacher_id', description: '班级有班主任' },
                { type: 'hasMany', table: 'class_students', localKey: 'id', description: '班级有多个学生关联' },
                { type: 'hasMany', table: 'users', localKey: 'id', description: '班级有多个学生' }
            ]
        },

        class_students: {
            name: 'class_students',
            displayName: '班级学生关联',
            category: 'school',
            description: '班级和学生的多对多关联关系',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '关联ID' },
                { name: 'class_id', type: 'bigint(20)', isForeignKey: true, references: 'classes.id', description: '班级ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'student_number', type: 'varchar(50)', description: '班级内学号' },
                { name: 'join_date', type: 'date', description: '加入日期' },
                { name: 'leave_date', type: 'date', description: '离开日期' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否活跃' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'classes', foreignKey: 'class_id', description: '关联属于班级' },
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '关联属于学生' }
            ]
        },

        curriculum_standards: {
            name: 'curriculum_standards',
            displayName: '课程标准',
            category: 'school',
            description: '课程标准和教学大纲',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '标准ID' },
                { name: 'school_id', type: 'bigint(20)', isForeignKey: true, references: 'schools.id', description: '学校ID' },
                { name: 'standard_name', type: 'varchar(100)', description: '标准名称' },
                { name: 'standard_code', type: 'varchar(50)', description: '标准代码' },
                { name: 'grade_range', type: 'varchar(20)', description: '适用年级范围' },
                { name: 'description', type: 'text', description: '标准描述' },
                { name: 'version', type: 'varchar(20)', description: '版本号' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否启用' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'schools', foreignKey: 'school_id', description: '标准属于学校' },
                { type: 'hasMany', table: 'subjects', localKey: 'id', description: '标准有多个学科' }
            ]
        },

        subjects: {
            name: 'subjects',
            displayName: '学科信息',
            category: 'school',
            description: '学科基本信息和配置',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '学科ID' },
                { name: 'curriculum_standard_id', type: 'bigint(20)', isForeignKey: true, references: 'curriculum_standards.id', description: '课程标准ID' },
                { name: 'subject_name', type: 'varchar(50)', description: '学科名称' },
                { name: 'subject_code', type: 'varchar(20)', description: '学科代码' },
                { name: 'description', type: 'text', description: '学科描述' },
                { name: 'grade_range', type: 'varchar(20)', description: '适用年级范围' },
                { name: 'subject_config', type: 'json', description: '学科配置' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否启用' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'curriculum_standards', foreignKey: 'curriculum_standard_id', description: '学科属于课程标准' }
            ]
        },

        // 作业管理系统
        homeworks: {
            name: 'homeworks',
            displayName: '作业模板',
            category: 'homework',
            description: '作业基本信息和配置',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '作业ID' },
                { name: 'title', type: 'varchar(200)', description: '作业标题' },
                { name: 'description', type: 'text', description: '作业描述' },
                { name: 'subject', type: 'varchar(50)', description: '学科' },
                { name: 'grade', type: 'int(11)', description: '年级' },
                { name: 'difficulty_level', type: 'int(11)', description: '难度等级(1-5)' },
                { name: 'estimated_time', type: 'int(11)', description: '预计完成时间(分钟)' },
                { name: 'total_score', type: 'decimal(5,2)', description: '总分' },
                { name: 'question_count', type: 'int(11)', description: '题目数量' },
                { name: 'created_by', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '创建者ID' },
                { name: 'knowledge_points', type: 'json', description: '关联知识点' },
                { name: 'tags', type: 'json', description: '标签' },
                { name: 'is_published', type: 'tinyint(1)', defaultValue: '0', description: '是否发布' },
                { name: 'is_template', type: 'tinyint(1)', defaultValue: '0', description: '是否为模板' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'created_by', description: '作业属于创建者' },
                { type: 'hasMany', table: 'questions', localKey: 'id', description: '作业有多个题目' },
                { type: 'hasMany', table: 'homework_assignments', localKey: 'id', description: '作业有多个分配记录' }
            ]
        },

        questions: {
            name: 'questions',
            displayName: '题目信息',
            category: 'homework',
            description: '作业题目详细信息',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '题目ID' },
                { name: 'homework_id', type: 'bigint(20)', isForeignKey: true, references: 'homeworks.id', description: '作业ID' },
                { name: 'content', type: 'text', description: '题目内容' },
                { name: 'question_type', type: 'enum', values: ['single_choice','multiple_choice','fill_blank','calculation','proof','application'], description: '题目类型' },
                { name: 'options', type: 'json', description: '选择题选项' },
                { name: 'correct_answer', type: 'text', description: '正确答案' },
                { name: 'score', type: 'decimal(5,2)', description: '题目分值' },
                { name: 'difficulty', type: 'int(11)', description: '难度等级(1-5)' },
                { name: 'order_index', type: 'int(11)', description: '题目顺序' },
                { name: 'knowledge_points', type: 'json', description: '关联知识点ID列表' },
                { name: 'explanation', type: 'text', description: '题目解析' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'homeworks', foreignKey: 'homework_id', description: '题目属于作业' }
            ]
        },

        homework_assignments: {
            name: 'homework_assignments',
            displayName: '作业分配',
            category: 'homework',
            description: '作业分配给学生或班级的记录',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '分配ID' },
                { name: 'homework_id', type: 'bigint(20)', isForeignKey: true, references: 'homeworks.id', description: '作业ID' },
                { name: 'assigned_by', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '分配者ID' },
                { name: 'assigned_to_type', type: 'enum', values: ['student','class','grade'], description: '分配目标类型' },
                { name: 'assigned_to_id', type: 'bigint(20)', description: '分配目标ID' },
                { name: 'due_date', type: 'datetime', description: '截止时间' },
                { name: 'start_time', type: 'datetime', description: '开始时间' },
                { name: 'time_limit', type: 'int(11)', description: '时间限制(分钟)' },
                { name: 'max_attempts', type: 'int(11)', defaultValue: '1', description: '最大尝试次数' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否活跃' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'homeworks', foreignKey: 'homework_id', description: '分配属于作业' },
                { type: 'belongsTo', table: 'users', foreignKey: 'assigned_by', description: '分配由教师创建' },
                { type: 'hasMany', table: 'homework_submissions', localKey: 'id', description: '分配有多个提交记录' }
            ]
        },

        homework_submissions: {
            name: 'homework_submissions',
            displayName: '作业提交',
            category: 'homework',
            description: '学生作业提交记录',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '提交ID' },
                { name: 'assignment_id', type: 'bigint(20)', isForeignKey: true, references: 'homework_assignments.id', description: '分配ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'answers', type: 'json', description: '答案数据' },
                { name: 'score', type: 'decimal(5,2)', description: '得分' },
                { name: 'total_score', type: 'decimal(5,2)', description: '总分' },
                { name: 'accuracy', type: 'decimal(5,2)', description: '正确率' },
                { name: 'time_spent', type: 'int(11)', description: '用时(秒)' },
                { name: 'attempt_number', type: 'int(11)', defaultValue: '1', description: '尝试次数' },
                { name: 'status', type: 'enum', values: ['draft','submitted','graded','reviewed'], description: '状态' },
                { name: 'submitted_at', type: 'datetime', description: '提交时间' },
                { name: 'graded_at', type: 'datetime', description: '评分时间' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'homework_assignments', foreignKey: 'assignment_id', description: '提交属于分配' },
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '提交属于学生' },
                { type: 'hasOne', table: 'grading_results', localKey: 'id', description: '提交有评分结果' }
            ]
        },

        homework_progress: {
            name: 'homework_progress',
            displayName: '答题进度',
            category: 'homework',
            description: '学生答题过程中的进度保存',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '进度ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'homework_id', type: 'bigint(20)', isForeignKey: true, references: 'homeworks.id', description: '作业ID' },
                { name: 'assignment_id', type: 'bigint(20)', isForeignKey: true, references: 'homework_assignments.id', description: '分配ID' },
                { name: 'progress_data', type: 'json', description: '进度数据' },
                { name: 'current_question', type: 'int(11)', description: '当前题目序号' },
                { name: 'completed_questions', type: 'int(11)', defaultValue: '0', description: '已完成题目数' },
                { name: 'total_questions', type: 'int(11)', description: '总题目数' },
                { name: 'time_spent', type: 'int(11)', defaultValue: '0', description: '已用时间(秒)' },
                { name: 'last_activity', type: 'datetime', description: '最后活动时间' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '进度属于学生' },
                { type: 'belongsTo', table: 'homeworks', foreignKey: 'homework_id', description: '进度属于作业' },
                { type: 'belongsTo', table: 'homework_assignments', foreignKey: 'assignment_id', description: '进度属于分配' }
            ]
        },

        homework_favorites: {
            name: 'homework_favorites',
            displayName: '作业收藏',
            category: 'homework',
            description: '学生收藏的作业',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '收藏ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'assignment_id', type: 'bigint(20)', isForeignKey: true, references: 'homework_assignments.id', description: '分配ID' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '收藏时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '收藏属于学生' },
                { type: 'belongsTo', table: 'homework_assignments', foreignKey: 'assignment_id', description: '收藏属于分配' }
            ]
        },

        homework_reminders: {
            name: 'homework_reminders',
            displayName: '作业提醒',
            category: 'homework',
            description: '作业截止时间提醒',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '提醒ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'assignment_id', type: 'bigint(20)', isForeignKey: true, references: 'homework_assignments.id', description: '分配ID' },
                { name: 'reminder_time', type: 'datetime', description: '提醒时间' },
                { name: 'reminder_type', type: 'enum', values: ['before_due','overdue','custom'], description: '提醒类型' },
                { name: 'is_sent', type: 'tinyint(1)', defaultValue: '0', description: '是否已发送' },
                { name: 'sent_at', type: 'datetime', description: '发送时间' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '提醒属于学生' },
                { type: 'belongsTo', table: 'homework_assignments', foreignKey: 'assignment_id', description: '提醒属于分配' }
            ]
        },

        grading_results: {
            name: 'grading_results',
            displayName: '评分结果',
            category: 'homework',
            description: '作业自动评分和手动评分结果',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '评分结果ID' },
                { name: 'submission_id', type: 'bigint(20)', isForeignKey: true, references: 'homework_submissions.id', description: '提交记录ID' },
                { name: 'result_data', type: 'json', description: '详细评分结果' },
                { name: 'total_score', type: 'decimal(5,2)', description: '总得分' },
                { name: 'total_possible', type: 'decimal(5,2)', description: '总分' },
                { name: 'accuracy', type: 'decimal(5,2)', description: '正确率(%)' },
                { name: 'grading_method', type: 'enum', values: ['auto','manual','hybrid'], description: '评分方式' },
                { name: 'graded_by', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '评分教师ID' },
                { name: 'graded_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '评分时间' },
                { name: 'reviewed_at', type: 'datetime', description: '复核时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'homework_submissions', foreignKey: 'submission_id', description: '评分属于提交' },
                { type: 'belongsTo', table: 'users', foreignKey: 'graded_by', description: '评分由教师完成' }
            ]
        },

        // 知识图谱系统
        knowledge_points: {
            name: 'knowledge_points',
            displayName: '知识点',
            category: 'knowledge',
            description: '数学知识点信息和层次结构',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '知识点ID' },
                { name: 'name', type: 'varchar(100)', description: '知识点名称' },
                { name: 'code', type: 'varchar(50)', isUnique: true, description: '知识点代码' },
                { name: 'description', type: 'text', description: '知识点描述' },
                { name: 'subject', type: 'varchar(50)', description: '学科' },
                { name: 'grade', type: 'int(11)', description: '年级' },
                { name: 'category', type: 'varchar(50)', description: '分类' },
                { name: 'difficulty_level', type: 'int(11)', description: '难度等级(1-5)' },
                { name: 'parent_id', type: 'bigint(20)', isForeignKey: true, references: 'knowledge_points.id', description: '父知识点ID' },
                { name: 'order_index', type: 'int(11)', description: '排序索引' },
                { name: 'is_core', type: 'tinyint(1)', defaultValue: '0', description: '是否核心知识点' },
                { name: 'learning_objectives', type: 'json', description: '学习目标' },
                { name: 'prerequisites', type: 'json', description: '前置知识点' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'knowledge_points', foreignKey: 'parent_id', description: '知识点有父知识点' },
                { type: 'hasMany', table: 'knowledge_points', localKey: 'id', description: '知识点有子知识点' },
                { type: 'hasMany', table: 'knowledge_relations', localKey: 'id', description: '知识点有多个关系' }
            ]
        },

        knowledge_relations: {
            name: 'knowledge_relations',
            displayName: '知识关系',
            category: 'knowledge',
            description: '知识点之间的关系',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '关系ID' },
                { name: 'source_id', type: 'bigint(20)', isForeignKey: true, references: 'knowledge_points.id', description: '源知识点ID' },
                { name: 'target_id', type: 'bigint(20)', isForeignKey: true, references: 'knowledge_points.id', description: '目标知识点ID' },
                { name: 'relation_type', type: 'enum', values: ['prerequisite','successor','related','contains','part_of'], description: '关系类型' },
                { name: 'strength', type: 'decimal(3,2)', description: '关系强度(0-1)' },
                { name: 'description', type: 'text', description: '关系描述' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否活跃' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'knowledge_points', foreignKey: 'source_id', description: '关系来源于知识点' },
                { type: 'belongsTo', table: 'knowledge_points', foreignKey: 'target_id', description: '关系指向知识点' }
            ]
        },

        math_symbols: {
            name: 'math_symbols',
            displayName: '数学符号',
            category: 'knowledge',
            description: '数学符号库和使用统计',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '符号ID' },
                { name: 'symbol_name', type: 'varchar(50)', description: '符号名称' },
                { name: 'symbol_text', type: 'varchar(10)', description: '符号文本' },
                { name: 'latex_code', type: 'varchar(100)', description: 'LaTeX代码' },
                { name: 'unicode', type: 'varchar(20)', description: 'Unicode编码' },
                { name: 'category', type: 'varchar(50)', description: '符号分类' },
                { name: 'subcategory', type: 'varchar(50)', description: '子分类' },
                { name: 'grade_range', type: 'varchar(20)', description: '适用年级范围' },
                { name: 'difficulty_level', type: 'int(11)', description: '难度等级' },
                { name: 'usage_frequency', type: 'int(11)', defaultValue: '0', description: '使用频率' },
                { name: 'is_common', type: 'tinyint(1)', defaultValue: '0', description: '是否常用' },
                { name: 'description', type: 'text', description: '符号描述' },
                { name: 'examples', type: 'json', description: '使用示例' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' }
            ],
            relationships: []
        },

        learning_paths: {
            name: 'learning_paths',
            displayName: '学习路径',
            category: 'knowledge',
            description: '个性化学习路径',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '路径ID' },
                { name: 'student_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '学生ID' },
                { name: 'path_name', type: 'varchar(100)', description: '路径名称' },
                { name: 'subject', type: 'varchar(50)', description: '学科' },
                { name: 'grade', type: 'int(11)', description: '年级' },
                { name: 'path_structure', type: 'json', description: '路径结构' },
                { name: 'current_position', type: 'int(11)', defaultValue: '0', description: '当前位置' },
                { name: 'completion_rate', type: 'decimal(5,2)', defaultValue: '0.00', description: '完成率' },
                { name: 'estimated_duration', type: 'int(11)', description: '预计时长(小时)' },
                { name: 'difficulty_level', type: 'int(11)', description: '难度等级' },
                { name: 'is_active', type: 'tinyint(1)', defaultValue: '1', description: '是否活跃' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'student_id', description: '路径属于学生' }
            ]
        },

        // 智能推荐系统
        user_behavior_logs: {
            name: 'user_behavior_logs',
            displayName: '用户行为日志',
            category: 'recommendation',
            description: '用户学习行为数据收集',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '日志ID' },
                { name: 'user_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '用户ID' },
                { name: 'session_id', type: 'varchar(100)', description: '会话ID' },
                { name: 'action_type', type: 'varchar(50)', description: '行为类型' },
                { name: 'target_type', type: 'varchar(50)', description: '目标类型' },
                { name: 'target_id', type: 'bigint(20)', description: '目标ID' },
                { name: 'action_data', type: 'json', description: '行为数据' },
                { name: 'context_data', type: 'json', description: '上下文数据' },
                { name: 'timestamp', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '时间戳' },
                { name: 'ip_address', type: 'varchar(45)', description: 'IP地址' },
                { name: 'user_agent', type: 'text', description: '用户代理' },
                { name: 'device_info', type: 'json', description: '设备信息' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'user_id', description: '日志属于用户' }
            ]
        },

        recommendation_results: {
            name: 'recommendation_results',
            displayName: '推荐结果',
            category: 'recommendation',
            description: '智能推荐算法结果',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '推荐ID' },
                { name: 'user_id', type: 'bigint(20)', isForeignKey: true, references: 'users.id', description: '用户ID' },
                { name: 'recommendation_type', type: 'enum', values: ['symbol','knowledge_point','homework','learning_path'], description: '推荐类型' },
                { name: 'context', type: 'json', description: '推荐上下文' },
                { name: 'recommendations', type: 'json', description: '推荐结果列表' },
                { name: 'algorithm_version', type: 'varchar(20)', description: '算法版本' },
                { name: 'confidence_score', type: 'decimal(5,4)', description: '置信度分数' },
                { name: 'is_clicked', type: 'tinyint(1)', defaultValue: '0', description: '是否被点击' },
                { name: 'is_accepted', type: 'tinyint(1)', defaultValue: '0', description: '是否被接受' },
                { name: 'feedback_score', type: 'int(11)', description: '反馈评分' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'expires_at', type: 'datetime', description: '过期时间' }
            ],
            relationships: [
                { type: 'belongsTo', table: 'users', foreignKey: 'user_id', description: '推荐属于用户' }
            ]
        },

        system_configs: {
            name: 'system_configs',
            displayName: '系统配置',
            category: 'recommendation',
            description: '系统配置参数',
            fields: [
                { name: 'id', type: 'bigint(20)', isPrimary: true, description: '配置ID' },
                { name: 'config_key', type: 'varchar(100)', isUnique: true, description: '配置键' },
                { name: 'config_value', type: 'text', description: '配置值' },
                { name: 'config_type', type: 'enum', values: ['string','number','boolean','json'], description: '配置类型' },
                { name: 'description', type: 'text', description: '配置描述' },
                { name: 'is_public', type: 'tinyint(1)', defaultValue: '0', description: '是否公开' },
                { name: 'is_editable', type: 'tinyint(1)', defaultValue: '1', description: '是否可编辑' },
                { name: 'created_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP', description: '创建时间' },
                { name: 'updated_at', type: 'datetime', defaultValue: 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP', description: '更新时间' }
            ],
            relationships: []
        }
    },

    // 关系定义
    relationships: [
        // 用户权限系统内部关系
        { from: 'users', to: 'user_sessions', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'notifications', type: 'one-to-many', label: '1:N' },

        // 学校组织架构关系
        { from: 'schools', to: 'grades', type: 'one-to-many', label: '1:N' },
        { from: 'grades', to: 'classes', type: 'one-to-many', label: '1:N' },
        { from: 'classes', to: 'class_students', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'class_students', type: 'one-to-many', label: '1:N' },
        { from: 'schools', to: 'curriculum_standards', type: 'one-to-many', label: '1:N' },
        { from: 'curriculum_standards', to: 'subjects', type: 'one-to-many', label: '1:N' },

        // 作业管理系统关系
        { from: 'users', to: 'homeworks', type: 'one-to-many', label: '1:N', description: '教师创建作业' },
        { from: 'homeworks', to: 'questions', type: 'one-to-many', label: '1:N' },
        { from: 'homeworks', to: 'homework_assignments', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'homework_assignments', type: 'one-to-many', label: '1:N', description: '教师分配作业' },
        { from: 'homework_assignments', to: 'homework_submissions', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'homework_submissions', type: 'one-to-many', label: '1:N', description: '学生提交作业' },
        { from: 'users', to: 'homework_progress', type: 'one-to-many', label: '1:N' },
        { from: 'homeworks', to: 'homework_progress', type: 'one-to-many', label: '1:N' },
        { from: 'homework_assignments', to: 'homework_progress', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'homework_favorites', type: 'one-to-many', label: '1:N' },
        { from: 'homework_assignments', to: 'homework_favorites', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'homework_reminders', type: 'one-to-many', label: '1:N' },
        { from: 'homework_assignments', to: 'homework_reminders', type: 'one-to-many', label: '1:N' },
        { from: 'homework_submissions', to: 'grading_results', type: 'one-to-one', label: '1:1' },
        { from: 'users', to: 'grading_results', type: 'one-to-many', label: '1:N', description: '教师评分' },

        // 知识图谱系统关系
        { from: 'knowledge_points', to: 'knowledge_points', type: 'one-to-many', label: '1:N', description: '父子关系' },
        { from: 'knowledge_points', to: 'knowledge_relations', type: 'one-to-many', label: '1:N', description: '源关系' },
        { from: 'knowledge_points', to: 'knowledge_relations', type: 'one-to-many', label: '1:N', description: '目标关系' },
        { from: 'users', to: 'learning_paths', type: 'one-to-many', label: '1:N' },

        // 智能推荐系统关系
        { from: 'users', to: 'user_behavior_logs', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'recommendation_results', type: 'one-to-many', label: '1:N' },

        // 跨模块关系
        { from: 'schools', to: 'users', type: 'one-to-many', label: '1:N' },
        { from: 'grades', to: 'users', type: 'one-to-many', label: '1:N' },
        { from: 'classes', to: 'users', type: 'one-to-many', label: '1:N' },
        { from: 'users', to: 'classes', type: 'one-to-one', label: '1:1', description: '班主任关系' }
    ],

    // 模块分类
    modules: {
        user: {
            name: '用户权限系统',
            color: '#ff6b6b',
            description: '管理用户认证、授权和会话',
            tables: ['users', 'user_sessions', 'notifications']
        },
        school: {
            name: '学校组织架构',
            color: '#4ecdc4',
            description: '管理学校、年级、班级等组织结构',
            tables: ['schools', 'grades', 'classes', 'class_students', 'curriculum_standards', 'subjects']
        },
        homework: {
            name: '作业管理系统',
            color: '#45b7d1',
            description: '管理作业创建、分发、提交和评分',
            tables: ['homeworks', 'questions', 'homework_assignments', 'homework_submissions', 'homework_progress', 'homework_favorites', 'homework_reminders', 'grading_results']
        },
        knowledge: {
            name: '知识图谱系统',
            color: '#96ceb4',
            description: '管理知识点、关系和学习路径',
            tables: ['knowledge_points', 'knowledge_relations', 'math_symbols', 'learning_paths']
        },
        recommendation: {
            name: '智能推荐系统',
            color: '#feca57',
            description: '管理用户行为分析和智能推荐',
            tables: ['user_behavior_logs', 'recommendation_results', 'system_configs']
        }
    }
};
