// 交互功能扩展
class DatabaseInteractions {
    constructor(visualization) {
        this.viz = visualization;
        this.init();
    }

    init() {
        this.setupAdvancedInteractions();
    }

    setupAdvancedInteractions() {
        // 扩展可视化类的方法
        this.viz.zoomIn = () => {
            const scale = this.viz.network.getScale();
            this.viz.network.moveTo({ scale: scale * 1.2 });
        };

        this.viz.zoomOut = () => {
            const scale = this.viz.network.getScale();
            this.viz.network.moveTo({ scale: scale * 0.8 });
        };

        this.viz.resetView = () => {
            this.viz.network.fit();
        };

        this.viz.toggleModule = (module, visible) => {
            if (visible) {
                this.viz.visibleModules.add(module);
            } else {
                this.viz.visibleModules.delete(module);
            }
            this.updateVisibleTables();
        };

        this.viz.changeLayout = (layoutType) => {
            let layoutOptions = {};
            switch (layoutType) {
                case 'hierarchical':
                    layoutOptions = {
                        hierarchical: {
                            enabled: true,
                            direction: 'UD',
                            sortMethod: 'directed',
                            nodeSpacing: 200,
                            levelSeparation: 150
                        }
                    };
                    break;
                case 'force':
                    layoutOptions = {
                        hierarchical: { enabled: false }
                    };
                    this.viz.network.setOptions({ physics: { enabled: true } });
                    break;
                case 'circular':
                    this.arrangeCircular();
                    return;
                case 'grid':
                    this.arrangeGrid();
                    return;
            }
            this.viz.network.setOptions({ layout: layoutOptions });
        };

        this.viz.performSearch = () => {
            const query = document.getElementById('tableSearch').value.toLowerCase();
            this.searchTables(query);
        };

        this.viz.closeModal = () => {
            document.getElementById('tableModal').style.display = 'none';
        };

        this.viz.exportDiagram = () => {
            this.exportToImage();
        };

        this.viz.toggleFullscreen = () => {
            this.toggleFullscreen();
        };

        this.viz.highlightConnectedNodes = (nodeId) => {
            this.highlightConnectedNodes(nodeId);
        };
    }

    updateVisibleTables() {
        const visibleTables = [];
        const visibleEdges = [];

        // 过滤可见的表
        Object.values(databaseSchema.tables).forEach(table => {
            if (this.viz.visibleModules.has(table.category)) {
                visibleTables.push(table.name);
            }
        });

        // 过滤可见的关系
        databaseSchema.relationships.forEach((rel, index) => {
            if (visibleTables.includes(rel.from) && visibleTables.includes(rel.to)) {
                visibleEdges.push(`edge_${index}`);
            }
        });

        // 更新网络显示
        const allNodes = this.viz.nodes.get();
        const allEdges = this.viz.edges.get();

        allNodes.forEach(node => {
            this.viz.nodes.update({
                id: node.id,
                hidden: !visibleTables.includes(node.id)
            });
        });

        allEdges.forEach(edge => {
            this.viz.edges.update({
                id: edge.id,
                hidden: !visibleEdges.includes(edge.id)
            });
        });

        // 更新侧边栏显示
        document.querySelectorAll('.category').forEach(category => {
            const categoryType = category.dataset.category;
            if (categoryType) {
                category.style.display = this.viz.visibleModules.has(categoryType) ? 'block' : 'none';
            }
        });
    }

    arrangeCircular() {
        const positions = {};
        const tables = Object.keys(databaseSchema.tables);
        const radius = 300;
        const centerX = 0;
        const centerY = 0;

        tables.forEach((tableName, index) => {
            const angle = (index / tables.length) * 2 * Math.PI;
            positions[tableName] = {
                x: centerX + Math.cos(angle) * radius,
                y: centerY + Math.sin(angle) * radius
            };
        });

        this.viz.network.setOptions({ physics: { enabled: false } });
        this.viz.network.setPositions(positions);
    }

    arrangeGrid() {
        const positions = {};
        const tables = Object.keys(databaseSchema.tables);
        const cols = Math.ceil(Math.sqrt(tables.length));
        const spacing = 250;

        tables.forEach((tableName, index) => {
            const row = Math.floor(index / cols);
            const col = index % cols;
            positions[tableName] = {
                x: col * spacing - (cols * spacing) / 2,
                y: row * spacing - (Math.ceil(tables.length / cols) * spacing) / 2
            };
        });

        this.viz.network.setOptions({ physics: { enabled: false } });
        this.viz.network.setPositions(positions);
    }

    searchTables(query) {
        const results = [];
        const resultsContainer = document.getElementById('searchResults');

        if (!query.trim()) {
            resultsContainer.innerHTML = '';
            return;
        }

        // 搜索表名和字段
        Object.values(databaseSchema.tables).forEach(table => {
            let matches = [];

            // 搜索表名
            if (table.name.toLowerCase().includes(query) || 
                table.displayName.toLowerCase().includes(query)) {
                matches.push({ type: 'table', text: table.displayName });
            }

            // 搜索字段
            table.fields.forEach(field => {
                if (field.name.toLowerCase().includes(query) || 
                    field.description.toLowerCase().includes(query)) {
                    matches.push({ type: 'field', text: `${field.name} - ${field.description}` });
                }
            });

            if (matches.length > 0) {
                results.push({
                    table: table,
                    matches: matches
                });
            }
        });

        // 显示搜索结果
        let html = '';
        if (results.length === 0) {
            html = '<div class="search-no-results">未找到匹配结果</div>';
        } else {
            results.forEach(result => {
                html += `
                    <div class="search-result-item" data-table="${result.table.name}">
                        <div class="search-result-table">${result.table.displayName}</div>
                        <div class="search-result-matches">
                            ${result.matches.map(match => 
                                `<span class="search-match ${match.type}">${match.text}</span>`
                            ).join('')}
                        </div>
                    </div>
                `;
            });
        }

        resultsContainer.innerHTML = html;

        // 添加点击事件
        resultsContainer.querySelectorAll('.search-result-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const tableName = e.currentTarget.dataset.table;
                this.viz.selectTable(tableName);
                this.focusOnTable(tableName);
            });
        });
    }

    focusOnTable(tableName) {
        const nodePosition = this.viz.network.getPositions([tableName]);
        if (nodePosition[tableName]) {
            this.viz.network.moveTo({
                position: nodePosition[tableName],
                scale: 1.5,
                animation: {
                    duration: 1000,
                    easingFunction: 'easeInOutQuad'
                }
            });
        }
    }

    highlightConnectedNodes(nodeId) {
        // 临时高亮连接的节点
        const connectedEdges = this.viz.edges.get().filter(edge => 
            edge.from === nodeId || edge.to === nodeId
        );

        const connectedNodes = new Set();
        connectedEdges.forEach(edge => {
            if (edge.from !== nodeId) connectedNodes.add(edge.from);
            if (edge.to !== nodeId) connectedNodes.add(edge.to);
        });

        // 添加临时高亮样式
        connectedNodes.forEach(connectedNodeId => {
            const table = databaseSchema.tables[connectedNodeId];
            const module = databaseSchema.modules[table.category];
            this.viz.nodes.update({
                id: connectedNodeId,
                color: {
                    background: this.viz.lightenColor(module.color, 40),
                    border: module.color
                }
            });
        });

        // 3秒后恢复
        setTimeout(() => {
            if (this.viz.selectedTable !== nodeId) {
                this.viz.resetHighlight();
            }
        }, 3000);
    }

    exportToImage() {
        // 创建导出选项对话框
        const exportOptions = `
            <div class="export-dialog">
                <h4>导出图表</h4>
                <div class="export-options">
                    <label>
                        <input type="radio" name="format" value="png" checked> PNG图片
                    </label>
                    <label>
                        <input type="radio" name="format" value="svg"> SVG矢量图
                    </label>
                    <label>
                        <input type="radio" name="format" value="pdf"> PDF文档
                    </label>
                </div>
                <div class="export-settings">
                    <label>
                        图片质量:
                        <select id="exportQuality">
                            <option value="1">标准</option>
                            <option value="2" selected>高清</option>
                            <option value="3">超高清</option>
                        </select>
                    </label>
                    <label>
                        <input type="checkbox" id="includeBackground" checked> 包含背景
                    </label>
                </div>
                <div class="export-actions">
                    <button onclick="this.performExport()" class="btn btn-primary">导出</button>
                    <button onclick="this.closeExportDialog()" class="btn btn-secondary">取消</button>
                </div>
            </div>
        `;

        // 显示导出对话框
        const dialog = document.createElement('div');
        dialog.className = 'export-modal';
        dialog.innerHTML = exportOptions;
        document.body.appendChild(dialog);

        // 绑定导出功能
        dialog.querySelector('.btn-primary').onclick = () => {
            this.performExport(dialog);
        };
        dialog.querySelector('.btn-secondary').onclick = () => {
            document.body.removeChild(dialog);
        };
    }

    performExport(dialog) {
        const format = dialog.querySelector('input[name="format"]:checked').value;
        const quality = parseInt(dialog.querySelector('#exportQuality').value);
        const includeBackground = dialog.querySelector('#includeBackground').checked;

        const canvas = this.viz.network.canvas.frame.canvas;
        const ctx = canvas.getContext('2d');

        if (format === 'png') {
            // 导出PNG
            const link = document.createElement('a');
            link.download = `database-schema-${new Date().getTime()}.png`;
            link.href = canvas.toDataURL('image/png', quality);
            link.click();
        } else if (format === 'svg') {
            // 导出SVG (需要额外实现)
            this.exportSVG();
        } else if (format === 'pdf') {
            // 导出PDF (需要额外实现)
            this.exportPDF();
        }

        document.body.removeChild(dialog);
    }

    exportSVG() {
        // SVG导出实现
        console.log('SVG导出功能待实现');
    }

    exportPDF() {
        // PDF导出实现
        console.log('PDF导出功能待实现');
    }

    toggleFullscreen() {
        const container = document.querySelector('.visualization-area');
        
        if (!document.fullscreenElement) {
            container.requestFullscreen().then(() => {
                container.classList.add('fullscreen');
                document.getElementById('fullscreenBtn').innerHTML = '<i class="fas fa-compress"></i> 退出全屏';
            });
        } else {
            document.exitFullscreen().then(() => {
                container.classList.remove('fullscreen');
                document.getElementById('fullscreenBtn').innerHTML = '<i class="fas fa-expand"></i> 全屏';
            });
        }
    }
}

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    const visualization = new DatabaseVisualization();
    const interactions = new DatabaseInteractions(visualization);
    
    // 添加键盘快捷键
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey || e.metaKey) {
            switch (e.key) {
                case '=':
                case '+':
                    e.preventDefault();
                    visualization.zoomIn();
                    break;
                case '-':
                    e.preventDefault();
                    visualization.zoomOut();
                    break;
                case '0':
                    e.preventDefault();
                    visualization.resetView();
                    break;
                case 'f':
                    e.preventDefault();
                    document.getElementById('tableSearch').focus();
                    break;
                case 's':
                    e.preventDefault();
                    visualization.exportDiagram();
                    break;
            }
        }
        
        if (e.key === 'Escape') {
            visualization.closeModal();
        }
    });

    // 添加窗口大小变化监听
    window.addEventListener('resize', () => {
        if (visualization.network) {
            visualization.network.redraw();
        }
    });

    // 添加主题切换功能
    const themeToggle = document.createElement('button');
    themeToggle.className = 'theme-toggle btn btn-icon';
    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    themeToggle.title = '切换主题';
    document.querySelector('.header-controls').appendChild(themeToggle);

    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        const isDark = document.body.classList.contains('dark-theme');
        themeToggle.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    });

    console.log('🎉 K-12数学教育系统数据库可视化演示已加载完成！');
    console.log('📊 数据统计:');
    console.log(`   - 数据表: ${Object.keys(databaseSchema.tables).length} 张`);
    console.log(`   - 关系连接: ${databaseSchema.relationships.length} 个`);
    console.log(`   - 模块分类: ${Object.keys(databaseSchema.modules).length} 个`);
    console.log('🔧 快捷键:');
    console.log('   - Ctrl/Cmd + = : 放大');
    console.log('   - Ctrl/Cmd + - : 缩小');
    console.log('   - Ctrl/Cmd + 0 : 重置视图');
    console.log('   - Ctrl/Cmd + F : 搜索');
    console.log('   - Ctrl/Cmd + S : 导出');
    console.log('   - ESC : 关闭模态框');
});
